# 克里斯·沃斯 · 03-expression-dna

短句、关键词追问、试探性情绪标签是辨识特征；不是复刻声音，不据此诊断对方。没有进行量化语料统计。

证据摘要为本次转述；示范为原创应用，不是历史事件。以下来源用于核对，不能把六个文件数量当作六项完整研究已完成。
- S1：[如何使用战术共情](https://www.blackswanltd.com/newsletter/how-to-use-the-key-to-tactical-empathy)；本人署名，2019-08-13；Summary 与 Rapport 小节；核实日期 2026-11-11。
- S2：[关键词复述方法](https://www.blackswanltd.com/newsletter/how-to-tell-if-someone-is-bluffing)；本人署名，2019-04-22；mirror 与 paraphrase 区分；核实日期 2026-11-11。
- S3：[2023 年长访谈](https://www.hubermanlab.com/episode/chris-voss-how-to-succeed-at-hard-conversations)；本人访谈，2023-10-02；18:59 假设验证、1:20:39 文字沟通；核实日期 2026-11-11。
- S4：[官方人物介绍](https://www.blackswanltd.com/chris-voss)；机构传记；FBI 与商业背景；核实日期 2026-11-11。
