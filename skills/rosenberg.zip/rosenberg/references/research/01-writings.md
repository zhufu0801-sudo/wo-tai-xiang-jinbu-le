# 马歇尔·罗森伯格 · 01-writings

四要素手册支持把观察、感受、需要、请求分开。本包将它操作化为四栏记录，而不强制用户说公式句。

证据摘要为本次转述；示范为原创应用，不是历史事件。以下来源用于核对，不能把六个文件数量当作六项完整研究已完成。
- S1：[四要素原始教学手册](https://www.nonviolentcommunication.com/pdf_files/4part_nvc_process.pdf)；一手教学资料；四个要素及表达/倾听两个方向；核实日期 2026-11-11。
- S2：[2000 年 Michael Mendizza 访谈](https://nonviolentcommunication.com/resources/articles-about-nvc/michael-mendizza/)；本人访谈；开头及关于选择、需要和工作共同体的问答；核实日期 2026-11-11。
- S3：[CNVC 创始人介绍](https://www.cnvc.org/about/marshall)；机构传记；背景、调解工作和关键年份；核实日期 2026-11-11。
